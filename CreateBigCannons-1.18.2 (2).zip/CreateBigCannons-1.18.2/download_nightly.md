# How to manually download nightly versions

## ***WARNING: NIGHTLY VERSIONS MIGHT BE UNSTABLE***

### How to download:

Requirements: GitHub account

1. Go to <https://github.com/rbasamoyai/CreateBigCannons/actions/workflows/gradle.yml>
2. Click on the latest workflow
3. Go to "Artifacts"
4. Click on the file starting with "createbigcannons-"
5. Extract the .jar from the downloaded .zip
